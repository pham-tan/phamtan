<?php
    include('includes/header.php');
?>
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Danh sách <small>bình luận</small>
        </h1>
        <ol class="breadcrumb">
            <li class="active">
                <i class="fa fa-dashboard"></i> Dashboard
            </li>
        </ol>
    </div>
</div>
<!-- .row -->
<?php include('includes/footer.php'); ?>  